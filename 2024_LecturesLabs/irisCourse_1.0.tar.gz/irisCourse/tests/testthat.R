library(testthat)
library(irisCourse)

test_check("irisCourse")
