data(iris)

test_that("Input must be a `data.frame`", {
  iris_matrix <- data.matrix(iris)
  expect_error(iris_plot(iris_matrix))
})