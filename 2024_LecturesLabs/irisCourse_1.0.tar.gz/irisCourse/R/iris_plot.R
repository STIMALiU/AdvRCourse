#' Function to make a Scatterplot using a couple of features of the \code{iris} dataset
#' 
#' Given a dataset like \code{iris}, the function \code{iris_plot} makes a scatterplot of 
#'      \code{Sepal.Length} vs. \code{Petal.Width} by \code{Species}
#' 
#' @param data A dataset like the \code{iris} dataset. Must be a \code{data.frame} object 
#'      with continuous variables \code{Sepal.Length} and. \code{Petal.Width}, and a categorical 
#'      variable, \code{Species}
#' @return Scatterplot of \code{Sepal.Length} vs. \code{Petal.Width} by \code{Species}
#' 
#' @export
#' 
#' @examples
#' data(iris)
#' iris_plot(iris)
#' 
#' @import ggplot2

iris_plot <- function(data) {
  
  # get rid of 'no visible binding for global variable' note
  Sepal.Length <- Petal.Width <- Species <- NULL
  
  # code for plotting
  ggplot2::ggplot(data) + 
    ggplot2::aes(x = Sepal.Length, y = Petal.Width, col = Species) +
    ggplot2::geom_point(alpha = 0.5)
  
}

